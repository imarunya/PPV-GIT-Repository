CREATE DATABASE  IF NOT EXISTS `ppvdataprod` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ppvdataprod`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ppvdataprod
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lager-planoption`
--

DROP TABLE IF EXISTS `lager-planoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lager-planoption` (
  `Plan-option` varchar(30) NOT NULL,
  UNIQUE KEY `Plan-option` (`Plan-option`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lager-planoption`
--

LOCK TABLES `lager-planoption` WRITE;
/*!40000 ALTER TABLE `lager-planoption` DISABLE KEYS */;
INSERT INTO `lager-planoption` VALUES (',1'),(',15'),(',27'),(',3'),(',33'),(',45'),(',5'),(',55'),(',6'),(',7'),(',75'),(',8'),(',95'),('0012'),('0024'),('0036'),('1'),('1,05'),('1,51'),('1,76'),('1,9'),('10,00'),('2,01'),('2,25'),('2,49'),('2,60'),('3,75'),('413'),('ALT1'),('ALT10'),('ALT100'),('ALT11'),('ALT12'),('ALT13'),('ALT14'),('ALT15'),('ALT16'),('ALT17'),('ALT18'),('ALT19'),('ALT2'),('ALT20'),('ALT21'),('ALT22'),('ALT23'),('ALT24'),('ALT25'),('ALT26'),('ALT27'),('ALT28'),('ALT29'),('ALT3'),('ALT30'),('ALT31'),('ALT32'),('ALT33'),('ALT34'),('ALT35'),('ALT36'),('ALT37'),('ALT38'),('ALT39'),('ALT4'),('ALT40'),('ALT41'),('ALT42'),('ALT43'),('ALT44'),('ALT45'),('ALT46'),('ALT47'),('ALT48'),('ALT49'),('ALT5'),('ALT50'),('ALT500'),('ALT51'),('ALT52'),('ALT53'),('ALT54'),('ALT55'),('ALT56'),('ALT57'),('ALT58'),('ALT59'),('ALT6'),('ALT60'),('ALT61'),('ALT62'),('ALT63'),('ALT64'),('ALT65'),('ALT66'),('ALT67'),('ALT68'),('ALT69'),('ALT7'),('ALT70'),('ALT71'),('ALT72'),('ALT73'),('ALT74'),('ALT75'),('ALT76'),('ALT77'),('ALT78'),('ALT79'),('ALT8'),('ALT80'),('ALT81'),('ALT82'),('ALT83'),('ALT84'),('ALT85'),('ALT86'),('ALT87'),('ALT88'),('ALT89'),('ALT9'),('ALT90'),('ALT91'),('ALT92'),('ALT93'),('ALT94'),('ALT95'),('ALT96'),('ALT97'),('ALT98'),('ALT99'),('ALTBAS'),('cwefd2345rw3r23'),('ew'),('EXKL 90X'),('EXKL 92X'),('EXKL 94X'),('EXKL 96X'),('hello'),('NTB1'),('NTB2'),('NTB3'),('NTB4'),('NTB5'),('NTB6'),('OPP1'),('OPP2'),('OPP3'),('OPP4'),('OPP5'),('OPP6'),('OPP7'),('OPP8'),('OPP9'),('wer');
/*!40000 ALTER TABLE `lager-planoption` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:52:47
