CREATE DATABASE  IF NOT EXISTS `ppvdataprod` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ppvdataprod`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ppvdataprod
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `servid`
--

DROP TABLE IF EXISTS `servid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servid` (
  `Servid-ID` int(11) NOT NULL AUTO_INCREMENT,
  `Servid-nr` varchar(10) NOT NULL DEFAULT '0',
  `Beskrivning` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Servid-ID`),
  KEY `Beskrivning` (`Beskrivning`),
  KEY `Servid-ID` (`Servid-ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servid`
--

LOCK TABLES `servid` WRITE;
/*!40000 ALTER TABLE `servid` DISABLE KEYS */;
INSERT INTO `servid` VALUES (1,'00000','Default'),(2,'00001','VPN-trafik'),(22,'00004','FBS-15'),(23,'00007','FBS-15'),(3,'00050','VCC-trafik'),(4,'00051','VCC-trafik'),(5,'00052','VCC-trafik'),(6,'00053','VCC-trafik'),(7,'00054','VCC-trafik'),(8,'00055','VCC-trafik'),(17,'00061','020'),(18,'00062','Ink Freephone'),(19,'00063','Advance 800 Ink'),(20,'00064','077,Freephone'),(21,'00065','Freephone'),(9,'00150','Centrex2000'),(11,'00156','Centrex 156'),(12,'00199','020'),(10,'00530','test'),(24,'00004','New Tool Test');
/*!40000 ALTER TABLE `servid` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:52:57
