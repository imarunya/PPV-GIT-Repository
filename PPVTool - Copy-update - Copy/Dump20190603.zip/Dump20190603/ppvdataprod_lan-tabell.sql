CREATE DATABASE  IF NOT EXISTS `ppvdataprod` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ppvdataprod`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ppvdataprod
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lan-tabell`
--

DROP TABLE IF EXISTS `lan-tabell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lan-tabell` (
  `LAN-userid` varchar(8) NOT NULL,
  `LAN-pwd` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Email` varchar(80) NOT NULL,
  `IBM-userid` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`LAN-userid`),
  UNIQUE KEY `LAN-userid` (`LAN-userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lan-tabell`
--

LOCK TABLES `lan-tabell` WRITE;
/*!40000 ALTER TABLE `lan-tabell` DISABLE KEYS */;
INSERT INTO `lan-tabell` VALUES ('dsf','sdf','therese.olofsson@tieto.com','AC84THN'),('arnfor',NULL,'arne.forsbo@tietoenator.com','AC84AFO'),('mipe41',NULL,'michiel.peters@tietoenator.com','AC84MIP'),('clan41',NULL,'claes.andersson@tietoenator.com','AC84IWY'),('forsschr',NULL,'christina.forsslund@tieto.com','A976CF'),('guol45',NULL,'gunilla.olsson@tieto.com','AC84GON'),('frli31',NULL,'fredrik.linde@tieto.com','AC84FLE'),('ivca00',NULL,'ext.iva.camilovic@tieto.com','AC84ICC'),('ayya00',NULL,'ayse.yagci@tieto.com','AC84AYA'),('dfds','dsfsf','susanna.vasko@tieto.com','AC84SVO'),('suni10',NULL,'surya.nikharey@tieto.com','AC84SNY'),('nako14',NULL,'naveen.kottam@tieto.com','AC84NAK'),('sck408',NULL,'abanti.goswami@tieto.com','AC84AGO'),('maku20',NULL,'manish.s.kumar@tieto.com','AC84MKU'),('pakh02',NULL,'parag.khairnar@tieto.com','AC84PAK'),('prba00',NULL,'prashant.balbudhe@tieto.com','AE28PRB'),('scy566',NULL,'neha.jain@tieto.com','AC84NES'),('scy584',NULL,'komal.gaikwad@tieto.com','AC84KGA'),('test','test','test','test'),('test1','TesT','abc@bad.com','null');
/*!40000 ALTER TABLE `lan-tabell` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:52:50
