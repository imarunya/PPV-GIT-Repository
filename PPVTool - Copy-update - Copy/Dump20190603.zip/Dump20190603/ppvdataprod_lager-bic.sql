CREATE DATABASE  IF NOT EXISTS `ppvdataprod` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ppvdataprod`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ppvdataprod
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lager-bic`
--

DROP TABLE IF EXISTS `lager-bic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lager-bic` (
  `BIC-lager-nr` int(11) NOT NULL AUTO_INCREMENT,
  `Kund-typ` varchar(1) NOT NULL,
  `Agree-typ` varchar(1) NOT NULL,
  `Prson-org-nm` varchar(10) NOT NULL,
  `Bill-cycle-code` varchar(2) NOT NULL,
  `Bill-cycle-dur` varchar(1) NOT NULL,
  `Bill-cycle-len` varchar(3) NOT NULL,
  `Bill-ind` varchar(1) NOT NULL,
  `Bus-res-type` varchar(1) NOT NULL,
  `Oper-ind` varchar(1) DEFAULT NULL,
  `Tims-split` varchar(1) NOT NULL,
  `Line-2-addr` varchar(55) NOT NULL,
  `Line-3-addr` varchar(55) NOT NULL,
  `LAN-userid` varchar(8) DEFAULT NULL,
  `Datum` datetime DEFAULT NULL,
  `Ben` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`BIC-lager-nr`),
  UNIQUE KEY `BIC-lager-nr` (`BIC-lager-nr`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lager-bic`
--

LOCK TABLES `lager-bic` WRITE;
/*!40000 ALTER TABLE `lager-bic` DISABLE KEYS */;
INSERT INTO `lager-bic` VALUES (1,'N','1','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','golars','1998-08-24 00:00:00','Enkel kund'),(2,'N','1','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','golars','1998-09-02 00:00:00','Vanlig kund'),(3,'N','1','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','golars','1999-03-02 00:00:00','Stockholm'),(4,'N','1','1234561234',' ','M','1','B','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','xhagerst','2003-09-01 00:00:00','Pottkund'),(5,'N','1','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','golars','1999-03-02 00:00:00','Malmö'),(6,'C','1','1234561234',' ','M','1','N','B','I','N','Testvägen 1A','123 45  MeraRabattStada','golars','1999-04-15 00:00:00','Kund Centrex'),(7,'C','1','1234561234',' ','M','1','N','B','I','N','Testvägen 1A','123 45  MeraRabattStada','golars','1999-04-15 00:00:00','Centrex kund2'),(8,'N','1','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','xhagerst','2002-03-12 00:00:00','Testkund med TM i A nummer'),(9,'N','2','1234561234',' ','M','1','N','B',' ','N','Testvägen 1A','123 45  MeraRabattStada','xhagerst','2003-05-05 00:00:00','Pottkund'),(10,'C','1','123455','45','W','234','5','B',NULL,'Y','test','test','test','2017-09-25 00:00:00','test'),(11,'C','1','345345','35','W','345','3','R',NULL,'Y','test','test','test','2017-09-25 00:00:00','test'),(12,'N','1','345435','34','W','345','3','B',NULL,'Y','test','test','test','2017-09-25 00:00:00','test'),(13,'N','1','11111111','bc','M','aa','M','R',NULL,'Y','AA','AAAA','test','2019-01-23 00:00:00','AAAA'),(14,'N','1','test','TE','D','231','2','B',NULL,'N','43','34t','test','2019-02-11 00:00:00','');
/*!40000 ALTER TABLE `lager-bic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:52:52
