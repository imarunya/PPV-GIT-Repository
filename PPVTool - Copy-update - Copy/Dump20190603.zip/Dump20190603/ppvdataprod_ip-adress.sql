CREATE DATABASE  IF NOT EXISTS `ppvdataprod` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `ppvdataprod`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: ppvdataprod
-- ------------------------------------------------------
-- Server version	5.7.18-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ip-adress`
--

DROP TABLE IF EXISTS `ip-adress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip-adress` (
  `IP-lpnr` int(11) NOT NULL AUTO_INCREMENT,
  `Maskin` varchar(4) NOT NULL,
  `Status` varchar(1) NOT NULL,
  `IP-adress` varchar(40) NOT NULL,
  `IP-adress2` varchar(40) NOT NULL,
  `Userid` varchar(8) NOT NULL,
  `Passw` varchar(8) NOT NULL,
  `Ben` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`IP-lpnr`),
  UNIQUE KEY `Maskin` (`Maskin`),
  UNIQUE KEY `IP-lpnr` (`IP-lpnr`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip-adress`
--

LOCK TABLES `ip-adress` WRITE;
/*!40000 ALTER TABLE `ip-adress` DISABLE KEYS */;
INSERT INTO `ip-adress` VALUES (1,'SYS2','0','131.116.44.145','tso2.telia.se','A948UP1','UPGUIN17','Förv&Utv'),(2,'SYSC','0','131.115.15.83','ibmsc.data.telia.se','A948UP1','UPGUI1','Utveckling'),(3,'SYS3','0','131.116.44.145','tso2.telia.se','A948UP1','UPGUIN17','Utveckling');
/*!40000 ALTER TABLE `ip-adress` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-03 15:52:57
